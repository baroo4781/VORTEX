require("dotenv").config();

const {
  Client, Collection, GatewayIntentBits, Partials, REST, Routes,
  SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder,
  ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType,
  ActivityType
} = require("discord.js");
const fs = require("node:fs");
const path = require("node:path");
const Database = require("better-sqlite3");

const TOKEN = process.env.DISCORD_TOKEN;
const CLIENT_ID = process.env.CLIENT_ID;
const GUILD_ID = process.env.GUILD_ID || null;
const DB_PATH = process.env.DB_PATH || "./data/vortex.sqlite";

if (!TOKEN || !CLIENT_ID) {
  console.error("[VORTEX] DISCORD_TOKEN ve CLIENT_ID ortam değişkenleri gerekli.");
  process.exit(1);
}

const dbDir = path.dirname(DB_PATH);
if (dbDir !== "." && !fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });
const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS tickets (
    channel_id TEXT PRIMARY KEY,
    guild_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
`);

const commands = [
  new SlashCommandBuilder().setName("yardim").setDescription("VORTEX komutlarını gösterir."),
  new SlashCommandBuilder().setName("ping").setDescription("Bot gecikmesini gösterir."),
  new SlashCommandBuilder().setName("sunucu").setDescription("Sunucu bilgilerini gösterir."),
  new SlashCommandBuilder().setName("kullanici").setDescription("Kullanıcı bilgilerini gösterir.")
    .addUserOption(o => o.setName("uye").setDescription("Bilgisi gösterilecek üye").setRequired(false)),
  new SlashCommandBuilder().setName("ban").setDescription("Bir üyeyi yasaklar.")
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption(o => o.setName("uye").setDescription("Yasaklanacak üye").setRequired(true))
    .addStringOption(o => o.setName("sebep").setDescription("Sebep").setMaxLength(400)),
  new SlashCommandBuilder().setName("kick").setDescription("Bir üyeyi sunucudan atar.")
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .addUserOption(o => o.setName("uye").setDescription("Atılacak üye").setRequired(true))
    .addStringOption(o => o.setName("sebep").setDescription("Sebep").setMaxLength(400)),
  new SlashCommandBuilder().setName("timeout").setDescription("Bir üyeye süreli iletişim kısıtlaması uygular.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName("uye").setDescription("Kısıtlanacak üye").setRequired(true))
    .addIntegerOption(o => o.setName("dakika").setDescription("Süre (1-40320 dakika)").setMinValue(1).setMaxValue(40320).setRequired(true))
    .addStringOption(o => o.setName("sebep").setDescription("Sebep").setMaxLength(400)),
  new SlashCommandBuilder().setName("temizle").setDescription("Son mesajları siler.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addIntegerOption(o => o.setName("adet").setDescription("1-100 arası").setMinValue(1).setMaxValue(100).setRequired(true)),
  new SlashCommandBuilder().setName("ticket-kur").setDescription("Ticket paneli gönderir.")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder().setName("ticket-kapat").setDescription("Açık ticket kanalını kapatır.")
].map(c => c.toJSON());

async function deployCommands() {
  const rest = new REST({ version: "10" }).setToken(TOKEN);
  const route = GUILD_ID
    ? Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID)
    : Routes.applicationCommands(CLIENT_ID);
  await rest.put(route, { body: commands });
  console.log(`[VORTEX] ${commands.length} komut yüklendi.`);
}

if (process.argv[2] === "deploy") {
  deployCommands().catch(err => { console.error("[VORTEX] Komut yükleme hatası:", err); process.exit(1); });
} else {
  const client = new Client({
    intents: [GatewayIntentBits.Guilds],
    partials: [Partials.Channel]
  });

  client.once("ready", () => {
    console.log(`[VORTEX] ${client.user.tag} olarak çevrimiçi.`);
    client.user.setActivity("VORTEX Yönetim", { type: ActivityType.Watching });
  });

  client.on("interactionCreate", async interaction => {
    try {
      if (interaction.isChatInputCommand()) {
        const name = interaction.commandName;
        const fail = msg => interaction.reply({ content: `❌ ${msg}`, ephemeral: true });
        const ok = msg => interaction.reply({ embeds: [new EmbedBuilder().setColor(0x2ecc71).setDescription(`✅ ${msg}`).setTimestamp()] });

        if (name === "yardim") {
          const e = new EmbedBuilder().setColor(0x5865f2).setTitle("VORTEX • Yardım")
            .setDescription("**Genel:** `/yardim` `/ping` `/sunucu` `/kullanici`\n**Moderasyon:** `/ban` `/kick` `/timeout` `/temizle`\n**Destek:** `/ticket-kur` `/ticket-kapat`");
          return interaction.reply({ embeds: [e], ephemeral: true });
        }
        if (name === "ping") return interaction.reply({ embeds: [new EmbedBuilder().setColor(0x5865f2).setTitle("VORTEX • Pong!").setDescription(`WebSocket: ${client.ws.ping} ms\nYanıt: ${Date.now() - interaction.createdTimestamp} ms`)], ephemeral: true });
        if (name === "sunucu") {
          const g = interaction.guild;
          const e = new EmbedBuilder().setColor(0x5865f2).setTitle(g.name).setThumbnail(g.iconURL({ size: 256 }))
            .addFields({ name: "Sunucu ID", value: g.id, inline: true }, { name: "Üye sayısı", value: String(g.memberCount), inline: true });
          return interaction.reply({ embeds: [e], ephemeral: true });
        }
        if (name === "kullanici") {
          const u = interaction.options.getUser("uye") || interaction.user;
          const e = new EmbedBuilder().setColor(0x5865f2).setTitle(`Kullanıcı: ${u.username}`).setThumbnail(u.displayAvatarURL({ size: 256 }))
            .addFields({ name: "ID", value: u.id, inline: true }, { name: "Hesap oluşturma", value: `<t:${Math.floor(u.createdTimestamp / 1000)}:D>`, inline: true });
          return interaction.reply({ embeds: [e], ephemeral: true });
        }
        if (name === "ban") {
          const u = interaction.options.getUser("uye");
          const reason = interaction.options.getString("sebep") || "Sebep belirtilmedi.";
          if (u.id === interaction.user.id) return fail("Kendini yasaklayamazsın.");
          const m = await interaction.guild.members.fetch(u.id).catch(() => null);
          if (m && !m.bannable) return fail("Bu üyeyi yasaklayamıyorum. Bot rolünün sırasını ve izinlerini kontrol et.");
          await interaction.guild.members.ban(u.id, { reason: `${reason} | Yetkili: ${interaction.user.tag}` });
          return ok(`${u.tag} yasaklandı. Sebep: ${reason}`);
        }
        if (name === "kick") {
          const u = interaction.options.getUser("uye");
          const m = await interaction.guild.members.fetch(u.id).catch(() => null);
          if (!m) return fail("Üye sunucuda bulunamadı.");
          if (!m.kickable) return fail("Bu üyeyi atamıyorum. Bot rolünün sırasını kontrol et.");
          await m.kick(interaction.options.getString("sebep") || `Yetkili: ${interaction.user.tag}`);
          return ok(`${u.tag} sunucudan atıldı.`);
        }
        if (name === "timeout") {
          const u = interaction.options.getUser("uye");
          const m = await interaction.guild.members.fetch(u.id).catch(() => null);
          if (!m) return fail("Üye bulunamadı.");
          if (!m.moderatable) return fail("Bu üyeye timeout uygulayamıyorum. Bot rolünün sırasını kontrol et.");
          const mins = interaction.options.getInteger("dakika");
          await m.timeout(mins * 60000, interaction.options.getString("sebep") || `Yetkili: ${interaction.user.tag}`);
          return ok(`${u.tag} ${mins} dakika timeout aldı.`);
        }
        if (name === "temizle") {
          const count = interaction.options.getInteger("adet");
          const deleted = await interaction.channel.bulkDelete(count, true);
          return interaction.reply({ content: `✅ ${deleted.size} mesaj silindi. Discord 14 günden eski mesajları toplu silmez.`, ephemeral: true });
        }
        if (name === "ticket-kur") {
          const e = new EmbedBuilder().setColor(0x5865f2).setTitle("VORTEX • Destek Merkezi")
            .setDescription("Destek ekibine ulaşmak için aşağıdaki butona bas.");
          const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId("vortex_ticket_open").setLabel("Ticket Oluştur").setEmoji("🎫").setStyle(ButtonStyle.Primary)
          );
          return interaction.reply({ embeds: [e], components: [row] });
        }
        if (name === "ticket-kapat") {
          const t = db.prepare("SELECT * FROM tickets WHERE channel_id = ? AND status = 'open'").get(interaction.channelId);
          if (!t) return fail("Bu kanal açık bir VORTEX ticket kanalı değil.");
          if (t.user_id !== interaction.user.id && !interaction.memberPermissions.has(PermissionFlagsBits.ManageChannels))
            return fail("Bu ticket'ı yalnızca açan kişi veya kanal yönetme yetkili kapatabilir.");
          db.prepare("UPDATE tickets SET status = 'closed' WHERE channel_id = ?").run(interaction.channelId);
          await interaction.reply({ content: "Ticket 5 saniye içinde kapatılacak." });
          setTimeout(() => interaction.channel?.delete("VORTEX ticket kapatıldı").catch(() => {}), 5000);
        }
      }

      if (interaction.isButton() && interaction.customId === "vortex_ticket_open") {
        const old = db.prepare("SELECT channel_id FROM tickets WHERE guild_id = ? AND user_id = ? AND status = 'open'").get(interaction.guildId, interaction.user.id);
        if (old) {
          const ch = interaction.guild.channels.cache.get(old.channel_id);
          if (ch) return interaction.reply({ content: `Zaten açık ticket'ın var: ${ch}`, ephemeral: true });
          db.prepare("UPDATE tickets SET status = 'closed' WHERE channel_id = ?").run(old.channel_id);
        }
        await interaction.deferReply({ ephemeral: true });
        const channel = await interaction.guild.channels.create({
          name: `ticket-${interaction.user.username}`.toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 90),
          type: ChannelType.GuildText,
          permissionOverwrites: [
            { id: interaction.guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
            { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
            { id: client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageChannels] }
          ],
          reason: `VORTEX ticket: ${interaction.user.tag}`
        });
        db.prepare("INSERT INTO tickets (channel_id, guild_id, user_id) VALUES (?, ?, ?)").run(channel.id, interaction.guildId, interaction.user.id);
        await channel.send({ content: `${interaction.user}`, embeds: [new EmbedBuilder().setColor(0x5865f2).setTitle("Destek talebin oluşturuldu").setDescription("Sorununu ayrıntılı şekilde yazabilirsin. Kapatmak için `/ticket-kapat` kullan.")] });
        await interaction.editReply({ content: `Ticket kanalın oluşturuldu: ${channel}` });
      }
    } catch (err) {
      console.error("[VORTEX] Etkileşim hatası:", err);
      const payload = { content: "Komut çalıştırılırken hata oluştu. Bot izinlerini ve rol sıralamasını kontrol et.", ephemeral: true };
      if (interaction.isRepliable()) {
        if (interaction.replied || interaction.deferred) await interaction.followUp(payload).catch(() => {});
        else await interaction.reply(payload).catch(() => {});
      }
    }
  });

  process.on("unhandledRejection", err => console.error("[VORTEX] Promise hatası:", err));
  client.login(TOKEN);
}
